package q2.csvfilesource;

import org.junit.Assert;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

public class TestComputation_CsvFileSource {

   @ParameterizedTest
   @CsvFileSource(resources = "/q2/csvfilesource/computation_dataset.csv")
   public void testGetDiscount(int id, int rate, int expectedDiscount) throws Exception {
       Computation com = new Computation();
       int result = com.getDiscount(id, rate);
       Assert.assertEquals(expectedDiscount, result);
   }
}
